---
name: raccoon-records-search
description: 根据关键字或分类/风格检索微店「浣熊唱片」商品并生成 report.html 报告。支持关键字检索与按分类检索两种模式。用户需提供 token（wdtoken）和时间戳（dash）；关键字模式还需 keyword，分类模式需用户确认分类 ID。当用户提到浣熊唱片、唱片检索、lp_fetcher、按分类/风格检索或需要查询该店商品时使用。
---

# 浣熊唱片商品检索

根据关键字或分类检索微店「浣熊唱片」（shopId: 1404154952）的商品情况。

## 全局约束

- 工作目录为项目根目录
- **仅允许**调用 `bin/lp_fetcher` 二进制可执行文件，命令形式为 `./bin/lp_fetcher <子命令> [参数]`
- **严禁**以下行为：
  - 生成任何脚本或临时可执行文件（如 `.py`、`.sh`、`.go` 等）
  - 执行任何 Go 相关命令（如 `go run`、`go build`、`go test` 等）
  - 通过其他方式间接调用 CLI（如 `bash -c`、管道、包装脚本等）
- 执行成功后仅告知用户结果路径，**不要**复述或汇总商品内容

---

## 场景一：关键字检索

### 触发条件

用户需要按关键字查询商品，且能提供以下三个参数（**缺一不可**）：

| 参数 | CLI 参数 | 说明 |
|------|----------|------|
| 关键字 | `--keyword` | 店铺内搜索词 |
| token | `--wdtoken` | API 鉴权参数 |
| 时间戳 | `--dash` | URL 防缓存时间戳 |

缺少任一参数时，先向用户索取，**不得**自行猜测或省略。

### 执行步骤

在项目根目录依次执行：

```bash
./bin/lp_fetcher search --keyword "<关键字>" --wdtoken "<token>" --dash "<时间戳>"
./bin/lp_fetcher render
```

- **Step 1**：`search` 调用微店 API，将结果写入 `search_result.json`
- **Step 2**：`render` 读取 JSON，生成 `report.html`
- **Step 3**：检查执行是否成功，告知用户结果

### 示例

```bash
./bin/lp_fetcher search --keyword "Highway To Hell" --wdtoken "82e78914" --dash "1781934291799"
./bin/lp_fetcher render
```

---

## 场景二：按分类/风格检索

### 强约束

- **只能**使用 `search_by_category` 子命令执行商品检索
- **严禁**使用 `search` 关键字搜索子命令（即使分类名、风格名、艺人名等看起来像搜索词，也不得调用 `search`）
- 若用户意图无法通过分类匹配完成，**终止技能**并建议用户改用场景一（关键字检索），**不得**在场景二内回退到 `search`

### 触发条件

用户希望按分类、风格、材质、厂牌、艺人专区等店铺分类浏览商品（如「爵士」「摇滚」「全新黑胶」「Taylor Swift」等），且能提供：

| 参数 | CLI 参数 | 说明 |
|------|----------|------|
| token | `--wdtoken` | API 鉴权参数 |
| 时间戳 | `--dash` | URL 防缓存时间戳（`search_by_category` 必填） |

缺少 token 或时间戳时，先向用户索取，**不得**自行猜测或省略。

### 执行步骤

#### Step 1：准备分类数据

检查项目根目录是否存在 `category_result.json`：

- **不存在**：执行以下命令获取分类配置：

```bash
./bin/lp_fetcher category --wdtoken "<token>"
```

- **已存在**：跳过此步，直接读取文件

#### Step 2：匹配候选分类

读取 `category_result.json` 内容（结构含 `cateList`，每项有 `cateId`、`cateName`，可嵌套 `childCateList`）。

根据用户描述的分类/风格意图，在全部层级中检索匹配项，整理出**候选分类列表**（每项包含分类名称与 `cateId`），并向用户提问确认要检索哪一个。

示例提问格式：

> 找到以下候选分类，请选择要检索的一项（回复序号或完整分类名）：
> 1. 爵士（cateId: 127630967）
> 2. Cool Jazz 冷爵士（cateId: 141851486）
> 3. …

#### Step 3：用户确认

- 用户选择的分类**必须**属于 Step 2 给出的候选列表（按序号或分类名匹配）
- 若用户输入**不属于**任何候选项：**终止技能**，告知用户未找到匹配分类，请重新描述或改用关键字检索
- 若用户选择有效：记录对应 `cateId`，继续执行

#### Step 4：按分类检索并生成报告

**仅允许**使用 `search_by_category`，**禁止**使用 `search`。

```bash
./bin/lp_fetcher search_by_category --cateId "<cateId>" --wdtoken "<token>" --dash "<时间戳>"
./bin/lp_fetcher render
```

- **Step 4a**：`search_by_category` 将结果写入 `search_result.json`（**不得**改用 `search`）
- **Step 4b**：`render` 生成 `report.html`
- **Step 4c**：检查执行是否成功，告知用户结果

---

## 结果文件

| 文件 | 用途 |
|------|------|
| `category_result.json` | 分类检索中间产物，含 `cateList`；用于匹配用户意图与 `cateId` |
| `search_result.json` | 检索中间产物，含 `count`、`status`、`msg`、`items`；用于判断执行成败 |
| `report.html` | 最终检索结果页面，供用户在浏览器中查看 |

检索结果均在 `report.html` 中展示，Agent **无需**读取或转述其中的商品信息（Step 2 读取 `category_result.json` 除外）。

## 异常处理

- `search_result.json` 中 `status == "failed"`：向用户说明 `msg`
  - 常见：`查询结果过多、请精确查询关键词`（结果超过 2 页，需缩小范围或换用更具体的分类）
- `category_result.json` 中 `status == "failed"`：向用户说明 `msg`，检查 token 是否有效
- 网络或未知错误：提示用户检查 token 与时间戳是否有效

## 反馈方式

执行成功后，仅告知用户：

- 检索已完成
- 报告已生成，路径为 `report.html`，请在浏览器中打开查看

执行失败时，说明对应 JSON 文件中的 `msg` 及可能原因（见异常处理）。
