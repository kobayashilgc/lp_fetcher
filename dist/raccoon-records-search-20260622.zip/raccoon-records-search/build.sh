mkdir -p bin && go build -o bin/lp_fetcher
